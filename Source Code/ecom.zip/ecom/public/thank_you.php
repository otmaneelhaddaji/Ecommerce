<?php require_once("../resources/config.php"); ?>
<?php include(TEMPLATE_FRONT . DS . "header.php"); ?>

<?php process_transaction(); ?>


<div class="container">
    <h1>Thank You!</h1>
</div>

<?php include(TEMPLATE_FRONT . DS . "footer.php"); ?>